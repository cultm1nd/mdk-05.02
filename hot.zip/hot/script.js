const header = document.querySelector('.moving_header');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    header.style.top = `${scrollTop}px`;
    return;
});

window.addEventListener("load", function () {
    document.querySelector("#img2").classList.add("a");
    document.querySelector("#head").classList.add("b");
})
//картинки
document.addEventListener('DOMContentLoaded', function () {
    let blocks = document.querySelectorAll('.block');

    function checkBlocksVisibility() {
        let windowHeight = window.innerHeight;

        blocks.forEach(block => {
            let blockPosition = block.getBoundingClientRect().top;

            if (blockPosition < windowHeight - 100) {
                block.style.opacity = "1";
                block.style.transform = "translateY(0)";
            }
        });
    }

    checkBlocksVisibility();

    window.addEventListener('scroll', function () {
        checkBlocksVisibility();
    });
});
// slider
const slides = $(".SP-slider");
const dotsContainer = $(".carousel-dots");
const interval = 2000; // Time interval for auto-sliding in milliseconds
let currentIndex = 0;

// Create pagination dots
for (let i = 0; i < slides.length; i++) {
    dotsContainer.append('<span class="dot" data-index="' + i + '"></span>');
}

const dots = $(".dot");

// Function to show a specific slide
function showSlide(index) {
    slides.hide();
    slides.eq(index).show();
    dots.removeClass("active");
    dots.eq(index).addClass("active");
}

// Initial slide display
showSlide(currentIndex);

// Auto slide
function autoSlide() {
    currentIndex = (currentIndex + 1) % slides.length;
    showSlide(currentIndex);
}

// Set an interval for auto-sliding
let sliderInterval = setInterval(autoSlide, interval);

// Handle dot click event
dots.click(function () {
    const dotIndex = $(this).data("index");
    showSlide(dotIndex);
    currentIndex = dotIndex;
    clearInterval(sliderInterval); // Stop auto-sliding
    sliderInterval = setInterval(autoSlide, interval); // Restart auto-sliding
});

// Handle next and previous button clicks
$("#nextButton").click(function () {
    currentIndex = (currentIndex + 1) % slides.length;
    showSlide(currentIndex);
    clearInterval(sliderInterval); // Stop auto-sliding
    sliderInterval = setInterval(autoSlide, interval); // Restart auto-sliding
});

$("#prevButton").click(function () {
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    showSlide(currentIndex);
    clearInterval(sliderInterval); // Stop auto-sliding
    slide
});
