const header = document.querySelector('.moving_header');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    header.style.top = `${scrollTop}px`;
    return;
});

window.addEventListener("load", function () {
    document.querySelector("#img2").classList.add("a");
    document.querySelector("#head").classList.add("b");
})

